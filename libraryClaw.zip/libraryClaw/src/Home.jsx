import React from "react";

import Ui from "./Ui";

const Home = () => {
  return (
    <>
      <div className="Home">
        <Ui />
      </div>
    </>
  );
};

export default Home;
